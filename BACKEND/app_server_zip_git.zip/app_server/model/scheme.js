const mongoose = require("mongoose");

const UPEID = mongoose.Schema({
    hk: Number,
    Soil_Moisture: Number,
    Soil_pH: Number,
    Temperature: Number,
    Humidity: Number,
    Light: Number
});

module.exports = mongoose.model("hk6", UPEID);