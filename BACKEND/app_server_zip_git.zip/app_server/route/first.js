const express = require("express")
const router=express.Router()
const path= require("path")
const db = require("./../model/scheme.js");
const mongoose = require("mongoose");
const axios = require('axios');
const {mailer}=require("./../mailer/nodemailer.js");
//_______________
let running=0;   //_________________
let l = 0;
let b=0;
let cmd=0;



con()

async function con() {
    try {
        await mongoose.connect("mongodb://127.0.0.1:27017/", {
            useNewUrlParser: true,
            useUnifiedTopology: true,
            serverSelectionTimeoutMS: 5000, 
        });
        console.log("MongoDB connected successfully");
    } catch (error) {
        console.error("Error connecting to MongoDB:", error);    }
}








router.get('/wether_rover_run_or_not', (req, res) => {
    console.log("working hk");
    //const running = 0;
    res.json({ running });
});

router.post('/run_rover_planting', async (req, res) => {
    console.log("planting post");                    
    //esp32 send l,b,cmd code
    
    const { length, breadth } = req.body;
    const command = 1;
    cmd=command;
    l=length;
    b=breadth;
    running=1;
    console.log(l);
    res.status(200).send('Data received successfully');
});

let moisture = 10;

router.post("/ldr-data", async(req, res) => {
    const { ldr,soilMoistureValue , temperature, humidity } = req.body;
    console.log(`Received LDR Value: ${ldr}`);
    console.log(`Received Temperature: ${temperature}°C`);
    console.log(`Received Humidity: ${humidity}%`);
    console.log(`Received soilMoistureValue: ${soilMoistureValue}%`);
//router.get("/ldr-data", async(req, res) => {
    cmd=0;
    running=0; 
    console.log(cmd);
       
    if (moisture<15){
        const percent_inc=moisture-15;
            //assumed to increase the moisture level by 1 % we need to produce 5L per sqmeter and flow rate of the motor is 10L/s
        const a=percent_inc*5*200;//assuming 200 sqm (a is num of litter to be produced)
        const time_s=a/10;
        const time_min=time_s/60;
            //send mail and response
    
        const mailid = "harikrisshna.r2023@vitstudent.ac.in";
        const content = `<h1>REMAINDER: this is ur current moisture lvl in the soilt ${moisture} and ${time_min} hours u have to run the water pump to achieve the required moisture level</h1>`;
        sent=mailer(mailid,content);
        if(sent){
            console.log("mail sent")
        }else{
            console.log("mail does'nt sent")
        };
                
    
    }
    //mongodb code
    const highval = await db.findOne().sort({ hk: -1 }); 
    const hk = highval.hk + 1;
    //const Soil_Moisture = 234.0;
    const Soil_pH = 22.0;
    //const Temperature = 7465.0;
    //const Humidity = 6.21;
    //const Light = 541.02;
            
    //const uploadedDb = await db.create({ "hk": hk,"Soil_Moisture": soilMoistureValue, "Soil_pH": Soil_pH, "Temperature": temperature , "Humidity": humidity , "Light": ldr});
    //console.log(uploadedDb);
    res.status(200).send({ message: "Data received successfully" });
});

router.post("/plant_data", (req, res) => {
    const { plant } = req.body;
    console.log(plant);
    cmd=0;
    running=0; 
    res.status(200).send({ message: "Data received successfully" });
});

router.post('/run_rover_sensing', async(req, res) => {
    const { length, breadth } = req.body;
    const command = 2;
    cmd=command;
    l=length;
    b=breadth;
    running=1;
    res.json({ message: 'Data sent to ESP32' });
    //const highval = await db.findOne().sort({ hk: -1 }); 
    //const hk = highval.hk + 1;
    //const Soil_Moisture = 234.0;
    //const Soil_pH = 22.0;
    //const Temperature = 7465.0;
    //const Humidity = 6.21;
    //const Light = 541.02;
            
    //const uploadedDb = await db.create({ "hk": hk,"Soil_Moisture": Soil_Moisture, "Soil_pH": Soil_pH, "Temperature": Temperature , "Humidity": Humidity , "Light": Light });
    //console.log(uploadedDb);
});
router.get("/dimensions", (req, res) => {
    const data = {
      length: l, // Example length value
      breadth: b,
      Command:cmd,
    };
    res.status(200).json(data);
});

router.get("/add_fake_data",async(req,res)=>{
    try {
            const highval = await db.findOne().sort({ hk: -1 }); 
            const hk = highval.hk + 1;
            //first v have to give a value for hk and enter the dat then use the above cmd
            //const hk = 1;
            const Soil_Moisture = 30.1;
            const Soil_pH = 38.5;
            const Temperature = 37.2;
            const Humidity = 18.23;
            const Light = 32.98;
            
            const uploadedDb = await db.create({ "hk": hk,"Soil_Moisture": Soil_Moisture, "Soil_pH": Soil_pH, "Temperature": Temperature , "Humidity": Humidity , "Light": Light });
            console.log(uploadedDb);
    
            const all = await db.find(); 
            //all.forEach(doc => console.log(doc.itemname)); 
    
            res.json(all);
        } catch (error) {
            console.error("Error in /load_fake_data route:", error);
            res.status(500).send("An error occurred");
        }
});

router.get("/prev_fetch_data",async(req,res)=>{
    try {
            console.log("post pre fetch");
            const highval = await db.findOne().sort({ hk: -1 }); 
            const val = highval.hk;
            const document = await db.findOne({ hk: val });
            console.log(document);
            res.json(document);
        } catch (error) {
            console.error("Error in /h:", error);
            res.status(500).send("An error occurred");
        }
});




module.exports=router