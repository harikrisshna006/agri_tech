const nodemailer = require("nodemailer");

async function mailer(email,content){
    //emai senderr
    console.log(email)
    // First, define send settings by creating a new transporter: 
    let transporter = nodemailer.createTransport({
        host: "smtp.gmail.com", // SMTP server address (usually mail.your-domain.com)
        port: 465, // Port for SMTP (usually 465)
        secure: true, // Usually true if connecting to port 465
        auth: {
            user: "harikrisshna.r@gmail.com", // Your email address
            pass: "vior wcet wqkv jugw", //cmxbvofbfugtjcyj",  Password (for gmail, your app password)
            // ⚠️ For better security, use environment variables set on the server for these values when deploying
        },
    });

    // Define and send message inside transporter.sendEmail() and await info about send from promise:
    let info = await transporter.sendMail({
        from: '"HK" <harikrisshna.r@gmail.com>',
        to: email,
        subject: "REMAINDER",
        html: content 
    });

    console.log(info.messageId); // Random ID generated after successful sent (optional)
    return(info.messageId);
}

module.exports={mailer};