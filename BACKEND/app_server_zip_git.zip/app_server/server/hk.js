const express = require('express');
const app = express();
const path = require('path');
const PORT = 3000;
const cors = require('cors');
const os = require('os');


// Function to get the local IP address
function getLocalIpAddress() {
    const interfaces = os.networkInterfaces();
    let ipAddress;

    Object.keys(interfaces).forEach((interfaceName) => {
        interfaces[interfaceName].forEach((interfaceInfo) => {
            if (interfaceInfo.family === 'IPv4' && !interfaceInfo.internal) {
                ipAddress = interfaceInfo.address;
            }
        });
    });

    return ipAddress;
}






app.use(cors());
//app.use("/",express.static(path.join(__dirname,"..", 'public')));

app.use(express.json())
app.use(express.urlencoded({ extended: true }));


app.use("/",require(path.join(__dirname,'..',"route","first.js")))

/*app.get('',(req,res)=>{
    res.status(404).sendFile(path.join(__dirname,"..",'views','404.html'));
});


app.listen(PORT,()=>{
    console.log(`server is running on ${PORT}`)
});*/

app.listen(PORT, () => {
    console.log(`Server running at http://${getLocalIpAddress()}:${PORT}/`);
});